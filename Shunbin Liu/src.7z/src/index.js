import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";

// 创建一个根节点
const root = ReactDOM.createRoot(document.getElementById("root"));

// 使用根节点渲染App组件
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
