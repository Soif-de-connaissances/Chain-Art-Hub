import React, { useState } from "react";
import "./TokenSwap.css";

// 模拟的代币数据
const tokens = [
  { symbol: "BNB", price: 717.71, change: 0.4 },
  { symbol: "BTC", price: 104154.8, change: 2.79 },
  { symbol: "ETH", price: 3460.7, change: 2.73 },
  { symbol: "XRP", price: 3.25, change: -0.62 },
  { symbol: "DOGE", price: 0.42379, change: 10.53 },
];

function TokenSwap() {
  const [swapOutToken, setSwapOutToken] = useState(tokens[0]);
  const [swapInToken, setSwapInToken] = useState(tokens[1]);
  const [swapQuantity, setSwapQuantity] = useState(0);

  const handleSwapOutTokenChange = (event) => {
    const selectedSymbol = event.target.value;
    const selected = tokens.find((token) => token.symbol === selectedSymbol);
    setSwapOutToken(selected);
  };

  const handleSwapInTokenChange = (event) => {
    const selectedSymbol = event.target.value;
    const selected = tokens.find((token) => token.symbol === selectedSymbol);
    setSwapInToken(selected);
  };

  const handleSwapQuantityChange = (event) => {
    setSwapQuantity(parseFloat(event.target.value));
  };

  return (
    <div className="token-swap-container">
      <h1>Token exchange</h1>
      <div className="swap-section">
        <div className="swap-input">
          <label>Swap out tokens :</label>
          <select
            value={swapOutToken.symbol}
            onChange={handleSwapOutTokenChange}
          >
            {tokens.map((token) => (
              <option key={token.symbol} value={token.symbol}>
                {token.symbol}
              </option>
            ))}
          </select>
        </div>
        <div className="swap-input">
          <label>Swap in tokens:</label>
          <select value={swapInToken.symbol} onChange={handleSwapInTokenChange}>
            {tokens.map((token) => (
              <option key={token.symbol} value={token.symbol}>
                {token.symbol}
              </option>
            ))}
          </select>
        </div>
        <div className="swap-input">
          <label>Swap in tokens:</label>
          <input
            type="number"
            value={swapQuantity}
            onChange={handleSwapQuantityChange}
          />
        </div>
        <button className="swap-button">exchange</button>
      </div>
    </div>
  );
}

export default TokenSwap;