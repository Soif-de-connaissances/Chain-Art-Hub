import React, { useState } from "react";
import "./AccountPage.css"; // 导入 CSS 文件

function AccountPage() {
  const [isFaceRecognitionEnabled, setIsFaceRecognitionEnabled] = useState(false);

  const handleFaceRecognitionToggle = () => {
    setIsFaceRecognitionEnabled(!isFaceRecognitionEnabled);
  };

  return (
    <div className="account-page">
      <h1 className="white-text">user account</h1> {/* 应用 white-text 类 */}
      <form className="account-form">
        <label htmlFor="username">user name:</label>
        <input type="text" id="username" name="username" required />
        <br />
        <label htmlFor="password">password:</label>
        <input type="password" id="password" name="password" required />
        <br />
        <label className="face-recognition-label" htmlFor="face-recognition">
          <input
            type="checkbox"
            id="face-recognition"
            name="face-recognition"
            checked={isFaceRecognitionEnabled}
            onChange={handleFaceRecognitionToggle}
          />
          <span>Turn on the camera to identify the identity</span>
        </label>
        <br />
        <button type="submit">log in</button>
      </form>
    </div>
  );
}

export default AccountPage;



