import React, { useState } from "react";
import "./TokenTrade.css";

// 模拟的代币数据
const tokens = [
  { symbol: "BNB", price: 717.71, change: 0.4 },
  { symbol: "BTC", price: 104154.8, change: 2.79 },
  { symbol: "ETH", price: 3460.7, change: 2.73 },
  { symbol: "XRP", price: 3.25, change: -0.62 },
  { symbol: "DOGE", price: 0.42379, change: 10.53 },
];

function TokenTrade() {
  // 状态管理
  const [selectedToken, setSelectedToken] = useState(tokens[0]);
  const [quantity, setQuantity] = useState(0);
  const [balance, setBalance] = useState(1000); // 模拟用户余额

  // 处理代币选择
  const handleTokenChange = (event) => {
    const selectedSymbol = event.target.value;
    const selected = tokens.find((token) => token.symbol === selectedSymbol);
    setSelectedToken(selected);
  };

  // 处理数量输入
  const handleQuantityChange = (event) => {
    setQuantity(parseFloat(event.target.value));
  };

  // 计算购买或出售后的余额
  const calculateBalance = (isBuy) => {
    if (isBuy) {
      const cost = quantity * selectedToken.price;
      if (cost <= balance) {
        setBalance(balance - cost);
      } else {
        alert("Insufficient balance");
      }
    } else {
      const amount = quantity * selectedToken.price;
      setBalance(balance + amount);
    }
  };

  return (
    <div className="token-trade-container">
      <h1>Token Trading</h1>
      <div className="token-list">
        <h2>Hot Cryptos</h2>
        {tokens.map((token) => (
          <div key={token.symbol} className="token-item">
            <span className="token-symbol">{token.symbol}</span>
            <span className="token-price">${token.price.toFixed(2)}</span>
            <span
              className={`token-change ${
                token.change >= 0 ? "positive" : "negative"
              }`}
            >
              {token.change >= 0 ? "+" : ""}
              {token.change.toFixed(2)}%
            </span>
          </div>
        ))}
      </div>
      <div className="trade-container">
        <div className="trade-panel">
          <div className="trade-section">
            <label>Spend</label>
            <input
              type="number"
              value={quantity}
              onChange={handleQuantityChange}
            />
            <select value={selectedToken.symbol} onChange={handleTokenChange}>
              {tokens.map((token) => (
                <option key={token.symbol} value={token.symbol}>
                  {token.symbol}
                </option>
              ))}
            </select>
          </div>
          <div className="trade-section">
            <label>Receive</label>
            <input
              type="number"
              disabled
              value={quantity * selectedToken.price}
            />
            <span>{selectedToken.symbol}</span>
          </div>
        </div>
        <button className="trade-button" onClick={() => calculateBalance(true)}>
          Buy
        </button>
        <button
          className="trade-button"
          onClick={() => calculateBalance(false)}
        >
          Sell
        </button>
        <div className="balance">
          <span>Balance: ${balance.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}

export default TokenTrade;