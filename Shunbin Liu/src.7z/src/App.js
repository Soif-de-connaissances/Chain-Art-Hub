import React, { useState } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import "./App.css";
import TokenTrade from "./TokenTrade";
import TokenSwap from "./TokenSwap";
import NFTGallery from "./NFTGallery";
import AccountPage from "./AccountPage";
import CommunityEvents from "./CommunityEvents"; // 新增的社区活动组件

function App() {
  return (
    <Router>
      <div className="app-container">
        <nav>
          <div className="left-links">
            <ul>
              <li>
                <Link to="/trade">Token trading</Link>
              </li>
              <li>
                <Link to="/swap">Token trading</Link>
              </li>
              <li>
                <Link to="/nft">NFT portrait</Link>
              </li>
              <li>
                <Link to="/community-events">Community activities</Link> 
              </li>
            </ul>
          </div>
          <div className="right-links">
            <ul>
              <li className="account-link">
                <Link to="/account">account</Link>
              </li>
            </ul>
          </div>
        </nav>
        <Routes>
          <Route path="/trade" element={<TokenTrade />} />
          <Route path="/swap" element={<TokenSwap />} />
          <Route path="/nft" element={<NFTGallery />} />
          <Route path="/account" element={<AccountPage />} />
          <Route path="/community-events" element={<CommunityEvents />} /> // 新增的社区活动路由
        </Routes>
      </div>
    </Router>
  );
}

export default App;



