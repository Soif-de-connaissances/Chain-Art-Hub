import React from "react";
import "./NFTGallery.css";

function NFTGallery() {
  const nfts = [
    {
      image: "/image4.png",
      price: "1 BTC",
      description: "This is a unique NFT portrait with high artistic value. ",
      totalVolume: "100 ETH",
      floorPrice: "0.5 ETH",
      bestOffer: "1.2 ETH",
      owner: "0x1234567890abcdef",
    },
    {
      image: "/image5.png",
      price: "1 BTC",
      description: "This NFT portrait showcases a beautiful landscape and is highly popular. ",
      totalVolume: "80 ETH",
      floorPrice: "0.4 ETH",
      bestOffer: "1.0 ETH",
      owner: "0xabcdef1234567890",
    },
    {
      image: "/image6.png",
      price: "1 BTC",
      description: "A creative NFT portrait has attracted the attention of many collectors.",
      totalVolume: "120 ETH",
      floorPrice: "0.6 ETH",
      bestOffer: "1.5 ETH",
      owner: "0x567890abcdef1234",
    },
    {
      image: "/image7.png",
      price: "1 BTC",
      description: "The unique artistic style makes this NFT portrait stand out.",
      totalVolume: "90 ETH",
      floorPrice: "0.45 ETH",
      bestOffer: "1.1 ETH",
      owner: "0x90abcdef12345678",
    },
    {
      image: "/image8.png",
      price: "1 BTC",
      description: "This NFT portrait is of great value as it embodies profound cultural connotations.",
      totalVolume: "110 ETH",
      floorPrice: "0.55 ETH",
      bestOffer: "1.3 ETH",
      owner: "0xdef1234567890abc",
    },
  ];

  return (
    <div className="nft-gallery-container">
      <h1>NFT portrait</h1>
      <div className="nft-gallery">
        {nfts.map((nft, index) => (
          <div className="nft-item" key={index}>
            <img src={nft.image} alt={`NFT ${index + 1}`} />
            <p className="nft-price">{nft.price}</p>
            <p className="nft-description">{nft.description}</p>
            <p className="nft-attributes">
              <span>Total trading volume: {nft.totalVolume}</span>
              <span>floor price: {nft.floorPrice}</span>
              <span>Best offer: {nft.bestOffer}</span>
              <span>holder: {nft.owner}</span>
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default NFTGallery;

