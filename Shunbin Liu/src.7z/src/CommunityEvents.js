import React from 'react';
import './CommunityEvents.css';

const CommunityEvents = () => {
  return (
    <div className="community-events">
      <div className="event-tabs">
        <div className="event-tab">
          <img src="/image1.png" alt="Event 1" />
          <h3 className="event-title">nft trade</h3>
          <p className="event-description">Welcome to our NFT trading event! Here, you can explore a vast collection of unique digital assets, from stunning artworks to rare collectibles. Engage in seamless trading, connect with like - minded enthusiasts, and be part of the future of digital ownership. Don't miss this chance to dive into the exciting world of NFTs!</p>
          <button className="enter-button">Enter</button> {/* 为每个事件添加 Enter 按钮 */}
        </div>
        <div className="event-tab">
          <img src="/image2.png" alt="Event 2" />
          <h3 className="event-title">show love!</h3>
          <p className="event-description">Join our NFT Donation Charity Event! We're leveraging the power of NFTs for good. Donate your digital masterpieces or collectibles as NFTs, which will be auctioned. The proceeds will go directly to support various charitable causes. Be a part of this innovative initiative, blend the digital art world with philanthropy, and make a positive impact on those in need.</p>
          <button className="enter-button">Enter</button> {/* 为每个事件添加 Enter 按钮 */}
        </div>
        <div className="event-tab">
          <img src="/image3.png" alt="Event 3" />
          <h3 className="event-title">NFT Quiz Event</h3>
          <p className="event-description">Get ready for our thrilling NFT Quiz Event! Test your knowledge about the fascinating world of NFTs. From the basics of blockchain technology behind NFTs to the latest trends in the digital art marketplace, our quiz covers it all. Prizes are up for grabs! Whether you're a seasoned NFT enthusiast or just starting to explore, this event offers a fun and educational way to engage with the NFT community. Don't miss out on this chance to win exciting rewards while expanding your NFT knowledge.</p>
          <button className="enter-button">Enter</button> {/* 为每个事件添加 Enter 按钮 */}
        </div>
      </div>
      <button className="enter-button hide">Enter</button> {/* 隐藏页面左下角的 Enter 按钮 */}
    </div>
  );
};

export default CommunityEvents;



